from typing import List

import re
import html
import string

import bibtexparser

# Regex patterns
DOI_RE = re.compile(r"(10\.\d{4,9}/[-._;()/:A-Z0-9]+)", re.I)
ARXIV_WORD_RE = re.compile(r"\barxiv\b", re.I)

def extract_doi_any(list_text: List[str]) -> str:
    """
    Extract DOI from any type of input string
    """

    for text in list_text:
        if not text:
            continue

        m = DOI_RE.search(text)
        if m:
            return m.group(1)
        
    return ""

def citation_type(venue:str=None,
                  citation:str=None,
                  scholar_bibtex:str=None,
                  link:str=None,
                  doi:str=None) -> str:
    """
    Determine citation type to pass determine which website for bib extraction to use
    """
    if ARXIV_WORD_RE.search(venue or "") or \
       ARXIV_WORD_RE.search(citation) or \
       ARXIV_WORD_RE.search(scholar_bibtex) or \
       ARXIV_WORD_RE.search(link):
         return 'arxiv'
    
    elif doi.startswith("10.1145/"):
        return 'acm'
    
    elif doi.startswith("10.1007/"):
        return 'springer'
    
    return 'fallback'

def bibtex_to_fields(bibtex_str: str) -> dict:
    """
    Parse bibtex to dictionary
    """
    if not bibtex_str:
        return {}
    try:
        db = bibtexparser.loads(bibtex_str)
    except Exception:
        return {}
    if not getattr(db, "entries", None):
        return {}
    e = db.entries[0]
    out = {}
    for k, v in e.items():
        if v is None:
            continue
        out[str(k).lower().strip()] = str(v).strip()
    return out

def normalize_ws(s: str) -> str:
    """
    Remove whitespace
    """
    return re.sub(r"\s+", " ", (s or "")).strip()

def strip_html_tags(s: str) -> str:
    if not s:
        return ""
    s = re.sub(r"<[^>]+>", " ", s)
    s = html.unescape(s)
    return normalize_ws(s)

def normalize_title(s: str) -> str:
    s = (s or "").strip().lower()
    s = s.replace("’", "'")
    s = "".join(ch for ch in s if ch not in string.punctuation)
    s = normalize_ws(s)
    return s

def normalize_authors_to_bibtex(author_str: str) -> str:
    s = normalize_ws(author_str)
    if not s:
        return ""
    
    if re.search(r"\s+and\s+", s):
        return s

    last_first_hits = len(re.findall(r"\b\w+,\s*\w+", s))
    if last_first_hits == 0 and "," in s:
        parts = [p.strip() for p in s.split(",") if p.strip()]
        if len(parts) >= 2:
            return " and ".join(parts)
    return s

def seq_ratio(a: str, b: str) -> float:
    """
    Fuzzy text match
    """
    from difflib import SequenceMatcher
    return SequenceMatcher(None, a, b).ratio()

def token_set_ratio(a: str, b: str) -> float:
    a = normalize_ws((a or "").lower())
    b = normalize_ws((b or "").lower())
    if not a or not b:
        return 0.0
    ta = set(a.split())
    tb = set(b.split())
    inter = ta & tb
    if not inter:
        return 0.0
    return len(inter) / max(1, len(ta | tb))

def make_bib_key(authors_bibtex: str, year: str, title: str) -> str:
    """
    firstauthorlastnameYEAR_shorttitle
    """
    y = re.sub(r"\D", "", year or "")
    y = y[:4] if len(y) >= 4 else "nd"

    first = ""
    if authors_bibtex:
        first = authors_bibtex.split(" and ", 1)[0].strip()
        # handle "Last, First"
        if "," in first:
            first = first.split(",", 1)[0].strip()
        else:
            # "First Last"
            toks = first.split()
            if toks:
                first = toks[-1]
    first = re.sub(r"[^A-Za-z0-9]+", "", first) or "anon"

    t = normalize_title(title)
    t = re.sub(r"[^a-z0-9 ]+", "", t)
    t = "_".join(t.split()[:6]) if t else "untitled"

    return f"{first}{y}_{t}"